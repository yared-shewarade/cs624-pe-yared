// Listing 6.1 Creating a theme file with a primary color
const colors = {
    primary: '#1976D2'
}

export { colors }